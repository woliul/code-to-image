import React, {useRef, useState} from 'react';
import {Light as SyntaxHighlighter} from 'react-syntax-highlighter';
// --- THEME IMPORTS ---
import {
    arta,
    atomOneDark,
    atomOneLight,
    dracula,
    githubGist,
    hybrid,
    monokai,
    rainbow,
    solarizedDark,
    solarizedLight,
    vs,
    vs2015,
} from 'react-syntax-highlighter/dist/esm/styles/hljs';
import {toJpeg, toPng, toSvg} from 'html-to-image';

// --- LANGUAGE IMPORTS ---
import javascript from 'react-syntax-highlighter/dist/esm/languages/hljs/javascript';
import python from 'react-syntax-highlighter/dist/esm/languages/hljs/python';
import css from 'react-syntax-highlighter/dist/esm/languages/hljs/css';
import xml from 'react-syntax-highlighter/dist/esm/languages/hljs/xml';
import json from 'react-syntax-highlighter/dist/esm/languages/hljs/json';

// --- LANGUAGE REGISTRATION ---
SyntaxHighlighter.registerLanguage('javascript', javascript);
SyntaxHighlighter.registerLanguage('python', python);
SyntaxHighlighter.registerLanguage('css', css);
SyntaxHighlighter.registerLanguage('html', xml);
SyntaxHighlighter.registerLanguage('json', json);


function App() {
    const [code, setCode] = useState(`const pluckDeep = key => obj => key.split('.').reduce((accum, key) => accum[key], obj)

const compose = (...fns) => res => fns.reduce((accum, next) => next(accum), res)

const unfold = (f, seed) => {
const go = (f, seed, acc) => {
const res = f(seed)
return res ? go(f, res[1], acc.concat([res[0]])) : acc
}
return go(f, seed, [])
}
`);
    const codeRef = useRef(null);
    const [selectedLanguage, setSelectedLanguage] = useState('javascript');
    const [selectedThemeName, setSelectedThemeName] = useState('vs2015');
    const [currentBgColor, setCurrentBgColor] = useState('#1e1e1e');
    const [isExportDropdownOpen, setIsExportDropdownOpen] = useState(false);

    const languageOptions = [
        {label: 'JavaScript', value: 'javascript'},
        {label: 'Python', value: 'python'},
        {label: 'CSS', value: 'css'},
        {label: 'HTML/XML', value: 'html'},
        {label: 'JSON', value: 'json'},
    ];

    const themeOptions = [
        {label: 'Atom One Dark', value: 'atomOneDark', themeObject: atomOneDark, backgroundColor: '#282c34'},
        {label: 'Atom One Light', value: 'atomOneLight', themeObject: atomOneLight, backgroundColor: '#fafafa'},
        {label: 'Dracula', value: 'dracula', themeObject: dracula, backgroundColor: '#282a36'},
        {label: 'GitHub (Dark)', value: 'githubGist', themeObject: githubGist, backgroundColor: '#24292e'},
        {label: 'GitHub (Light)', value: 'vs', themeObject: vs, backgroundColor: '#ffffff'},
        {label: 'Monokai', value: 'monokai', themeObject: monokai, backgroundColor: '#272822'},
        {label: 'Hybrid', value: 'hybrid', themeObject: hybrid, backgroundColor: '#1d1f21'},
        {label: 'Rainbow', value: 'rainbow', themeObject: rainbow, backgroundColor: '#3f4144'},
        {label: 'Arta', value: 'arta', themeObject: arta, backgroundColor: '#222222'},
        {label: 'Solarized Dark', value: 'solarizedDark', themeObject: solarizedDark, backgroundColor: '#002b36'},
        {label: 'Solarized Light', value: 'solarizedLight', themeObject: solarizedLight, backgroundColor: '#fdf6e3'},
        {label: 'VS Code Modern Dark', value: 'vs2015', themeObject: vs2015, backgroundColor: '#1e1e1e'},
    ];

    const handleDownloadImage = (format) => {
        if (!codeRef.current) {
            alert('Code snippet element not found.');
            return;
        }

        let imagePromise;
        let fileName;

        switch (format) {
            case 'png':
                imagePromise = toPng(codeRef.current, {cacheBust: true});
                fileName = 'code-snippet.png';
                break;
            case 'svg':
                imagePromise = toSvg(codeRef.current, {cacheBust: true});
                fileName = 'code-snippet.svg';
                break;
            case 'jpeg':
                imagePromise = toJpeg(codeRef.current, {cacheBust: true, quality: 0.95});
                fileName = 'code-snippet.jpeg';
                break;
            default:
                alert('Invalid format selected.');
                return;
        }

        imagePromise
            .then((dataUrl) => {
                const link = document.createElement('a');
                link.download = fileName;
                link.href = dataUrl;
                link.click();
            })
            .catch((err) => {
                console.error('Failed to download image:', err);
                alert(`Failed to download image as ${format}. Check console for details.`);
            });
    };

    return (
        // Main container (no padding here, body handles full background and centering)
        <div style={{
            width: '100%',
            maxWidth: 'auto', // Slightly increased max-width to match the image better
            boxSizing: 'border-box',
            fontFamily: 'Inter, sans-serif'
        }}>
            {/* Outer container for the app content, mimicking the window - NO SHADOW HERE */}
            <div style={{
                backgroundColor: '#282c34', // Dark background for the window itself
                borderRadius: '12px',
                // boxShadow: '0 10px 20px rgba(0, 0, 0, 0.5)', // Removed shadow from here
                padding: '20px',
                width: '100%',
                boxSizing: 'border-box',
                display: 'flex',
                flexDirection: 'column',
            }}>
                {/* Window Controls (Traffic Lights) and Top Bar */}
                <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '20px',
                    paddingBottom: '10px',
                    // borderBottom: '1px solid #3a3a3a' // Removed border bottom
                }}>

                    {/* Top Right Controls (Language, Theme, Settings, Tweet, Export) */}
                    <div style={{display: 'flex', gap: '15px', flexWrap: 'wrap', alignItems: 'center'}}>
                        {/* Language Select Dropdown */}
                        <div style={{display: 'flex', alignItems: 'center'}}>
                            <label htmlFor="language-select" style={{
                                marginRight: '8px',
                                fontSize: '15px',
                                color: '#abb2bf'
                            }}>Lang:</label> {/* Adjusted label color */}
                            <select
                                id="language-select"
                                value={selectedLanguage}
                                onChange={(e) => setSelectedLanguage(e.target.value)}
                                style={{
                                    padding: '6px 10px',
                                    fontSize: '14px',
                                    borderRadius: '6px',
                                    border: '1px solid #3e4452',
                                    backgroundColor: '#3e4452',
                                    color: '#abb2bf',
                                    outline: 'none'
                                }}


                            >
                                {languageOptions.map((option) => (
                                    <option key={option.value} value={option.value}>
                                        {option.label}
                                    </option>
                                ))}
                            </select>
                        </div>

                        {/* Theme Select Dropdown */}
                        <div style={{display: 'flex', alignItems: 'center'}}>

                            <label htmlFor="theme-select" style={{
                                marginRight: '8px',
                                fontSize: '15px',
                                color: '#abb2bf'
                            }}>Theme:</label> {/* Adjusted label color */}
                            <select
                                id="theme-select"
                                value={selectedThemeName}
                                onChange={(e) => {
                                    const newThemeName = e.target.value;
                                    setSelectedThemeName(newThemeName);
                                    const chosenThemeOption = themeOptions.find(option => option.value === newThemeName);
                                    if (chosenThemeOption) {
                                        setCurrentBgColor(chosenThemeOption.backgroundColor);
                                    }
                                }}
                                style={{
                                    padding: '6px 10px',
                                    fontSize: '14px',
                                    borderRadius: '6px',
                                    border: '1px solid #3e4452',
                                    backgroundColor: '#3e4452',
                                    color: '#abb2bf',
                                    outline: 'none'
                                }}
                            >
                                {themeOptions.map((option) => (
                                    <option key={option.value} value={option.value}>
                                        {option.label}
                                    </option>
                                ))}
                            </select>
                        </div>

                        {/* Settings Button */}
                        <button
                            onClick={() => alert('Settings functionality coming soon!')}
                            style={{
                                padding: '8px 12px',
                                fontSize: '14px',
                                cursor: 'pointer',
                                backgroundColor: '#3e4452', // Match dropdowns
                                color: '#abb2bf',
                                border: 'none',
                                borderRadius: '6px',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '5px'
                            }}
                        >
                            ⚙️ Settings
                        </button>

                        {/* Tweet Button */}
                        <button
                            onClick={() => {
                                const tweetText = encodeURIComponent("Check out this cool code snippet I generated!");
                                const appUrl = encodeURIComponent(window.location.href);
                                window.open(`https://twitter.com/intent/tweet?text=${tweetText}&url=${appUrl}`, '_blank');
                            }}
                            style={{
                                padding: '8px 12px',
                                fontSize: '14px',
                                cursor: 'pointer',
                                backgroundColor: '#1DA1F2',
                                color: 'white',
                                border: 'none',
                                borderRadius: '6px'
                            }}
                        >
                            Tweet
                        </button>

                        {/* Export Dropdown */}
                        <div style={{position: 'relative', display: 'inline-block'}}>

                            <button
                                onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
                                style={{
                                    padding: '8px 12px',
                                    fontSize: '14px',
                                    cursor: 'pointer',
                                    backgroundColor: '#56b6c2', // Teal/Cyan color from VS Code
                                    color: '#282c34', // Dark text for light button
                                    border: 'none',
                                    borderRadius: '6px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '5px'
                                }}
                            >
                                Export
                                <span style={{fontSize: '10px', marginLeft: '5px'}}>▼</span>
                            </button>

                            {isExportDropdownOpen && (
                                <div
                                    style={{
                                        position: 'absolute',
                                        top: '100%',
                                        right: '0',
                                        backgroundColor: '#3e4452', // Darker background for dropdown
                                        border: '1px solid #555',
                                        borderRadius: '6px',
                                        boxShadow: '0px 4px 8px 0px rgba(0,0,0,0.3)',
                                        zIndex: 10,
                                        minWidth: '150px',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        marginTop: '5px'
                                    }}
                                >
                                    <button
                                        onClick={() => {
                                            handleDownloadImage('png');
                                            setIsExportDropdownOpen(false);
                                        }}
                                        style={{
                                            padding: '8px 12px',
                                            background: 'none',
                                            border: 'none',
                                            textAlign: 'left',
                                            cursor: 'pointer',
                                            color: '#abb2bf',
                                            borderBottom: '1px solid #555',
                                        }} // Added border for separation
                                    >
                                        Download as PNG
                                    </button>
                                    <button
                                        onClick={() => {
                                            handleDownloadImage('svg');
                                            setIsExportDropdownOpen(false);
                                        }}
                                        style={{
                                            padding: '8px 12px',
                                            background: 'none',
                                            border: 'none',
                                            textAlign: 'left',
                                            cursor: 'pointer',
                                            color: '#abb2bf',
                                            borderBottom: '1px solid #555',
                                        }}
                                    >
                                        Download as SVG
                                    </button>
                                    <button
                                        onClick={() => {
                                            handleDownloadImage('jpeg');
                                            setIsExportDropdownOpen(false);
                                        }}
                                        style={{
                                            padding: '8px 12px',
                                            background: 'none',
                                            border: 'none',
                                            textAlign: 'left',
                                            cursor: 'pointer',
                                            color: '#abb2bf'
                                        }}
                                    >
                                        Download as JPEG
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Code Input Area */}

                <textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    rows="10"
                    style={{
                        width: '100%',
                        backgroundColor: '#2e323b', // Background from the image for input/code area
                        color: '#e0e0e0',
                        padding: '15px',
                        fontSize: '16px',
                        borderRadius: '8px',
                        border: 'none', // Removed border
                        marginBottom: '20px',
                        resize: 'vertical',
                        outline: 'none',
                        boxSizing: 'border-box'
                    }}
                    placeholder="Paste your code here..."
                />

                {/* Code Display Area - Now with the shadow */}
                <div
                    ref={codeRef}
                    style={{
                        backgroundColor: currentBgColor, // Dynamic theme background
                        padding: '20px',
                        borderRadius: '8px',
                        overflowX: 'auto',
                        boxShadow: '0 8px 16px rgba(0,0,0,0.4)', // Shadow applied here
                        boxSizing: 'border-box',
                        minHeight: 'auto'
                    }}
                >{/* Traffic Light Dots */}
                    <div style={{display: 'flex', gap: '8px'}}>
                        <div style={{
                            width: '12px',
                            height: '12px',
                            borderRadius: '50%',
                            backgroundColor: '#ff5f56',
                            border: '1px solid #e0443e'
                        }}></div>
                        {/* Red with border */}
                        <div style={{
                            width: '12px',
                            height: '12px',
                            borderRadius: '50%',
                            backgroundColor: '#ffbd2e',
                            border: '1px solid #e0a22a'
                        }}></div>
                        {/* Yellow with border */}
                        <div style={{
                            width: '12px',
                            height: '12px',
                            borderRadius: '50%',
                            backgroundColor: '#27c93f',
                            border: '1px solid #22b53b'
                        }}></div>
                        {/* Green with border */}
                    </div>
                    <SyntaxHighlighter
                        language={selectedLanguage}
                        style={themeOptions.find(opt => opt.value === selectedThemeName)?.themeObject || atomOneDark}
                        customStyle={{
                            margin: 0,
                            paddingTop: '15px',
                            paddingBottom: '0px',
                            paddingLeft: '0px',
                            paddingRight: '0px',
                            whiteSpace: 'pre-wrap',
                            wordBreak: 'break-word',
                            fontSize: '14px',
                            lineHeight: '1.5', backgroundColor: 'transparent'}}
                    >
                        {code}
                    </SyntaxHighlighter>
                </div>
            </div>
        </div>
    );
}

export default App;